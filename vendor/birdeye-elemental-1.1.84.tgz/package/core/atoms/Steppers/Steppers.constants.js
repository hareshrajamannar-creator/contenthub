const e={COMPLETED:"completed",ACTIVE:"active"};export{e as STEPPER_STATUS_CONSTANTS};
