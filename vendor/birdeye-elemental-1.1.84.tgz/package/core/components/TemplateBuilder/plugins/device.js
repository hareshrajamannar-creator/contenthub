function i(i,d){var e;null===(e=null==i?void 0:i.Devices)||void 0===e||e.add({id:"mobile-415",name:"Mobile 415",width:"415px"})}export{i as default};
