const t=t=>{const o=parseFloat(t);return o<=12?"1.6":o<=18?"1.5":o<=24?"1.4":o<=36?"1.25":o<=48?"1.15":"1.1"};export{t as calculateLineHeightForFontSize};
