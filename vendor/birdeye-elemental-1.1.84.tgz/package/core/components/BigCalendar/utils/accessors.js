function t(t,n){let o=null;return"function"==typeof n?o=n(t):"string"==typeof n&&"object"==typeof t&&null!=t&&n in t&&(o=t[n]),o}const n=n=>o=>t(o,n);export{t as accessor,n as wrapAccessor};
