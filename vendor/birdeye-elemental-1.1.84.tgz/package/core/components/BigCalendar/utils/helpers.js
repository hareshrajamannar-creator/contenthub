function n(n,c){n&&n.apply(null,[].concat(c))}export{n as notify};
