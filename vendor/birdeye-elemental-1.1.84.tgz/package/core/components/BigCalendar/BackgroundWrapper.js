import o from"./NoopWrapper.js";export{o as default};
