function e(e){return e.children}export{e as default};
