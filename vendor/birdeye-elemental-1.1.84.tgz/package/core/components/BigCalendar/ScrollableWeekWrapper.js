import e from"react";const r=r=>{let{children:t}=r;return e.createElement("div",{className:"rbc-row-content-scroll-container"},t)};export{r as default};
